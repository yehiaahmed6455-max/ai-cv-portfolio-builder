import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useInView } from 'framer-motion';
import {
  Phone,
  Mail,
  ChevronDown,
  MessageCircle,
  Briefcase,
  Send,
  CheckCircle2,
  Sparkles,
  Gem,
  Globe,
  Smartphone,
  GraduationCap,
  ArrowUpRight,
  X,
} from 'lucide-react';
import { HeroBackdrop, PortraitRings, AboutCanvas } from './components/Scene3D';
import TiltCard from './components/TiltCard';
import { workProjects, type WorkProject } from './data/projects';

/* ------------------------------------------------------------------ */
/*  البيانات                                                           */
/* ------------------------------------------------------------------ */

const PHONE_DISPLAY = '01012297429';
const PHONE_WA = '201012297429';
const EMAIL = 'yehiaahmed6455@gmail.com';

const PORTRAIT = 'https://i.ibb.co/MDThr8bs/IMG-20260929-WA0007.jpg';

const projects = workProjects;

const serviceOptions = [
  'موقع إلكتروني',
  'منصة تعليمية',
  'متجر إلكتروني',
  'تطبيق موبايل',
  'تصميم واجهات وهوية',
  'خدمة أخرى',
];

const marqueeItems = ['منصات تعليمية', 'مواقع احترافية', 'متاجر إلكترونية', 'تطبيقات موبايل', 'تصميم واجهات', 'هوية بصرية', 'محاكاة وتدريب', 'حجز أونلاين'];

/* ------------------------------------------------------------------ */
/*  مكونات مساعدة                                                      */
/* ------------------------------------------------------------------ */

function Counter({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const dur = 1500;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setVal(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref} dir="ltr">
      {suffix}
      {val}
    </span>
  );
}

function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (ref.current)
        ref.current.style.transform = `translate(${e.clientX - 190}px, ${e.clientY - 190}px)`;
    };
    window.addEventListener('mousemove', move, { passive: true });
    return () => window.removeEventListener('mousemove', move);
  }, []);
  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-x-auto top-0 left-0 z-[4] hidden h-[380px] w-[380px] rounded-full md:block"
      style={{
        background: 'radial-gradient(circle, rgba(139,92,246,0.11), rgba(236,192,120,0.06) 45%, transparent 70%)',
        mixBlendMode: 'screen',
      }}
    />
  );
}

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: (d: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: d, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

/* ------------------------------------------------------------------ */
/*  التطبيق                                                            */
/* ------------------------------------------------------------------ */

export default function App() {
  const [name, setName] = useState('');
  const [service, setService] = useState(serviceOptions[0]);
  const [details, setDetails] = useState('');
  const [active, setActive] = useState<WorkProject | null>(null);

  useEffect(() => {
    document.documentElement.lang = 'ar';
    document.documentElement.dir = 'rtl';
  }, []);

  useEffect(() => {
    document.body.style.overflow = active ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [active]);

  const sendWhatsApp = () => {
    if (!name.trim() || !details.trim()) return;
    const msg =
      `السلام عليكم يحيى 👋\n\n` +
      `الاسم: ${name.trim()}\n` +
      `الخدمة المطلوبة: ${service}\n` +
      `تفاصيل الطلب: ${details.trim()}\n\n` +
      `— مرسلة من موقعك الشخصي`;
    window.open(`https://wa.me/${PHONE_WA}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const canSend = name.trim().length > 0 && details.trim().length > 0;

  return (
    <div dir="rtl" className="relative min-h-screen overflow-x-hidden bg-[#07070d] text-[#eceaf4]">
      <div className="noise-overlay" aria-hidden="true" />
      <CursorGlow />

      {/* ====================== الشريط العلوي ====================== */}
      <motion.nav
        initial={{ y: -70, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="fixed top-0 inset-x-0 z-50"
      >
        <div className="mx-auto max-w-6xl px-4 pt-4">
          <div className="glass-panel gold-border flex h-14 items-center justify-between rounded-2xl px-5">
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#ecc078] to-[#a87f35] font-black text-sm text-[#1a1206] shadow-[0_8px_20px_-6px_rgba(236,192,120,0.5)]">
                YA
              </span>
              <span className="hidden text-sm font-extrabold tracking-tight sm:block" dir="ltr">
                YEHIA.DEV
              </span>
            </a>
            <div className="flex items-center gap-5 text-sm font-semibold text-white/55 sm:gap-7">
              <a href="#about" className="transition-colors hover:text-[#ecc078]">نبذة عني</a>
              <a href="#work" className="transition-colors hover:text-[#ecc078]">أعمالي</a>
              <a href="#contact" className="transition-colors hover:text-[#ecc078]">تواصل معايا</a>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* ====================== الهيدر ====================== */}
      <header id="top" className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-5 pt-28 pb-16">
        <HeroBackdrop />
        {/* توهجات زخرفية */}
        <div className="pointer-events-none absolute right-[10%] top-[18%] h-72 w-72 rounded-full bg-[#8b5cf6]/12 blur-[110px]" aria-hidden="true" />
        <div className="pointer-events-none absolute bottom-[12%] left-[8%] h-80 w-80 rounded-full bg-[#ecc078]/10 blur-[120px]" aria-hidden="true" />

        <div className="relative flex max-w-3xl flex-col items-center text-center">
          {/* شارة */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0}
            className="glass-panel mb-10 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold text-white/70"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#ecc078] opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#ecc078]" />
            </span>
            متاح لمشاريع جديدة
          </motion.div>

          {/* الصورة + الحلقات 3D */}
          <motion.div
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
            className="relative mb-10"
          >
            <PortraitRings />
            <img
              src={PORTRAIT}
              alt="يحيى أحمد"
              className="relative z-10 h-52 w-52 rounded-full border-[3px] border-white/15 object-cover object-top shadow-[0_0_70px_-12px_rgba(236,192,120,0.5),0_30px_60px_-20px_rgba(0,0,0,0.8)] sm:h-64 sm:w-64"
            />
          </motion.div>

          {/* الاسم */}
          <motion.h1
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.3}
            className="text-glow-gold text-5xl font-black tracking-tight sm:text-7xl"
            dir="ltr"
          >
            YEHIA{' '}
            <span className="bg-gradient-to-l from-[#ecc078] via-[#f4d9a5] to-[#9f8bf5] bg-clip-text text-transparent">
              AHMED
            </span>
          </motion.h1>

          {/* الوصف */}
          <motion.p
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.42}
            className="mt-5 text-lg font-extrabold text-white/85 sm:text-2xl"
          >
            مصمم ومطور منصات ومواقع وتطبيقات
          </motion.p>
          <motion.p
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.52}
            className="mt-4 max-w-xl text-sm leading-loose text-white/50 sm:text-base"
          >
            بحوّل فكرتك لمنتج رقمي كامل وجاهز للإطلاق — من أول التخطيط والتصميم لحد التطوير والنشر،
            بشغل متقن وتواصل واضح في كل خطوة.
          </motion.p>

          {/* بيانات التواصل */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.64}
            className="mt-8 flex flex-wrap items-center justify-center gap-3"
          >
            <a
              href={`tel:${PHONE_DISPLAY}`}
              className="glass-panel flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition-colors hover:border-[#ecc078]/60 hover:text-[#ecc078]"
            >
              <Phone className="h-4 w-4 text-[#ecc078]" />
              <span dir="ltr">{PHONE_DISPLAY}</span>
            </a>
            <a
              href={`mailto:${EMAIL}`}
              className="glass-panel flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition-colors hover:border-[#ecc078]/60 hover:text-[#ecc078]"
            >
              <Mail className="h-4 w-4 text-[#ecc078]" />
              <span dir="ltr">{EMAIL}</span>
            </a>
          </motion.div>

          {/* أزرار */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.76}
            className="mt-9 flex flex-wrap items-center justify-center gap-4"
          >
            <a
              href="#work"
              className="group flex items-center gap-2 rounded-2xl bg-gradient-to-l from-[#ecc078] to-[#c99a45] px-8 py-4 text-sm font-black text-[#1a1206] shadow-[0_18px_40px_-12px_rgba(236,192,120,0.55)] transition-all hover:-translate-y-1 hover:shadow-[0_24px_50px_-10px_rgba(236,192,120,0.7)]"
            >
              <Briefcase className="h-4 w-4" />
              شوف أعمالي
            </a>
            <a
              href="#contact"
              className="glass-panel gold-border flex items-center gap-2 rounded-2xl px-8 py-4 text-sm font-black text-white/85 transition-all hover:-translate-y-1 hover:text-white"
            >
              <MessageCircle className="h-4 w-4 text-[#9f8bf5]" />
              كلمني دلوقتي
            </a>
          </motion.div>
        </div>

        <a href="#about" className="absolute bottom-6 right-1/2 translate-x-1/2 animate-bounce text-white/35">
          <ChevronDown className="h-6 w-6" />
        </a>
      </header>

      {/* ====================== ماركي الخدمات ====================== */}
      <div className="relative border-y border-white/6 bg-white/[0.015] py-5" dir="ltr">
        <div className="flex overflow-hidden">
          <div className="animate-marquee flex shrink-0 -translate-x-1/2 items-center gap-10 pl-10">
            {[...marqueeItems, ...marqueeItems].map((item, i) => (
              <span key={i} className="flex items-center gap-10 whitespace-nowrap" dir="rtl">
                <span className="text-sm font-bold text-white/45">{item}</span>
                <Gem className="h-3.5 w-3.5 text-[#ecc078]/70" />
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ====================== نبذة عني ====================== */}
      <section id="about" className="relative mx-auto max-w-6xl px-5 py-24">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="glass-panel gold-border relative overflow-hidden rounded-[2.5rem] px-7 py-12 sm:px-12 sm:py-14"
        >
          <AboutCanvas />
          <div className="relative">
            <span className="mb-3 inline-block text-xs font-black tracking-[0.25em] text-[#ecc078]">نبذة عني</span>
            <h2 className="mb-6 text-3xl font-black leading-snug sm:text-4xl">
              من الفكرة…{' '}
              <span className="bg-gradient-to-l from-[#ecc078] to-[#9f8bf5] bg-clip-text text-transparent">
                لمنتج شغّال على أرض الواقع
              </span>
            </h2>
            <p className="max-w-3xl text-sm leading-loose text-white/60 sm:text-base">
              بشتغل في تصميم وتطوير المنصات التعليمية والمواقع والتطبيقات من سنين، ونفّذت مشاريع
              حقيقية بيستخدمها آلاف الطلاب والعملاء يومياً في مصر والوطن العربي. بمسك المشروع من أوله
              لآخره: بفهم فكرتك واحتياج جمهورك، بصمم واجهات مريحة وسهلة، بطوّر بأحدث التقنيات،
              وبسلّمك منتج مجرّب وجاهز للإطلاق — ومعاك بعد التسليم في أي تعديل أو تطوير.
            </p>
            <div className="mt-10 grid max-w-xl grid-cols-3 gap-5">
              {[
                { to: 40, suffix: '+', label: 'مشروع منفّذ' },
                { to: 7, suffix: '+', label: 'منصة وتطبيق' },
                { to: 100, suffix: '%', label: 'رضا العملاء' },
              ].map((s) => (
                <div key={s.label} className="glass-panel rounded-2xl p-4 text-center sm:p-5">
                  <div className="text-2xl font-black text-[#ecc078] sm:text-4xl">
                    <Counter to={s.to} suffix={s.suffix} />
                  </div>
                  <div className="mt-1.5 text-[11px] font-bold text-white/45 sm:text-xs">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3">
              {[
                { icon: GraduationCap, text: 'خبرة في المنصات التعليمية' },
                { icon: Globe, text: 'مواقع ومتاجر احترافية' },
                { icon: Smartphone, text: 'تطبيقات بأداء عالي' },
                { icon: Sparkles, text: 'هوية وتصميم مميز' },
              ].map((f) => (
                <span key={f.text} className="flex items-center gap-2 text-xs font-bold text-white/55 sm:text-sm">
                  <f.icon className="h-4 w-4 text-[#9f8bf5]" />
                  {f.text}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* ====================== أعمالي ====================== */}
      <section id="work" className="relative mx-auto max-w-6xl px-5 pb-28">
        <div className="pointer-events-none absolute left-[5%] top-[30%] h-72 w-72 rounded-full bg-[#4fe0ee]/8 blur-[110px]" aria-hidden="true" />
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7 }}
          className="mb-12"
        >
          <span className="mb-3 inline-block text-xs font-black tracking-[0.25em] text-[#ecc078]">أعمالي</span>
          <h2 className="text-3xl font-black sm:text-4xl">مشاريع حقيقية، <span className="text-white/45">لعملاء حقيقيين</span></h2>
        </motion.div>

        <div className="grid gap-7 sm:grid-cols-2" style={{ perspective: '1400px' }}>
          {projects.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 36 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.65, delay: (i % 2) * 0.08 }}
              className={i < 2 ? 'sm:col-span-2' : ''}
            >
              <TiltCard intensity={i < 2 ? 5 : 8} className="h-full">
                <article className="glass-panel gold-border flex h-full flex-col overflow-hidden rounded-3xl">
                  <div className={`relative overflow-hidden ${i < 2 ? 'h-64 sm:h-80' : 'h-52'}`}>
                    <img
                      src={p.cover}
                      alt={`${p.name} — ${p.type}`}
                      loading="lazy"
                      className="h-full w-full object-cover object-top"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#07070d]/90 via-transparent to-transparent" />
                    <span className="absolute bottom-4 right-4 rounded-full border border-white/10 bg-black/55 px-3.5 py-1.5 text-[11px] font-black text-[#ecc078] backdrop-blur">
                      {p.type}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col px-6 pb-6 pt-5">
                    <h3 className="text-xl font-black">{p.name}</h3>
                    <p className="mt-2.5 text-sm leading-loose text-white/55">{p.short}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {p.tags.slice(0, 4).map((t) => (
                        <span key={t} className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-bold text-white/60">
                          {t}
                        </span>
                      ))}
                    </div>
                    <div className="mt-5 flex flex-wrap gap-3">
                      <button
                        type="button"
                        onClick={() => setActive(p)}
                        className="rounded-xl bg-gradient-to-l from-[#ecc078] to-[#c99a45] px-4 py-2.5 text-xs font-black text-[#1a1206]"
                      >
                        View Project
                      </button>
                      <a
                        href={p.url}
                        target="_blank"
                        rel="noreferrer"
                        className="glass-panel inline-flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-black text-white/80"
                      >
                        فتح المشروع
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </a>
                    </div>
                  </div>
                </article>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <button type="button" aria-label="إغلاق" className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setActive(null)} />
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              className="relative z-10 max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-white/10 bg-[#0c0c14] p-6 sm:rounded-3xl sm:p-8"
            >
              <button
                type="button"
                onClick={() => setActive(null)}
                className="absolute left-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5"
                aria-label="إغلاق"
              >
                <X className="h-4 w-4" />
              </button>
              <p className="text-[11px] font-black tracking-[0.2em] text-[#ecc078]">{active.type}</p>
              <h3 className="mt-2 text-2xl font-black sm:text-3xl">{active.name}</h3>
              <div className="mt-5 overflow-hidden rounded-2xl border border-white/10">
                <img src={active.cover} alt={active.name} className="h-52 w-full object-cover object-top sm:h-64" />
              </div>
              <div className="mt-6 space-y-5 text-sm leading-loose text-white/65">
                <section>
                  <h4 className="mb-1 font-black text-[#ecc078]">Overview</h4>
                  <p>{active.overview}</p>
                </section>
                <section>
                  <h4 className="mb-1 font-black text-[#ecc078]">The Idea</h4>
                  <p>{active.idea}</p>
                </section>
                <section>
                  <h4 className="mb-1 font-black text-[#ecc078]">Features</h4>
                  <ul className="list-disc space-y-1 pr-5">
                    {active.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>
                </section>
                <section>
                  <h4 className="mb-1 font-black text-[#ecc078]">User Experience</h4>
                  <p>{active.ux}</p>
                </section>
                <section>
                  <h4 className="mb-1 font-black text-[#ecc078]">My Work</h4>
                  <p>{active.myWork}</p>
                </section>
                <section>
                  <h4 className="mb-3 font-black text-[#ecc078]">Project Gallery</h4>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {active.gallery.map((g) => (
                      <figure key={g.src} className="overflow-hidden rounded-xl border border-white/10">
                        <img src={g.src} alt={g.caption} className="h-40 w-full object-cover object-top" />
                        <figcaption className="px-3 py-2 text-[11px] font-bold text-white/45">{g.caption}</figcaption>
                      </figure>
                    ))}
                  </div>
                </section>
              </div>
              <a
                href={active.url}
                target="_blank"
                rel="noreferrer"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-[#ecc078] to-[#c99a45] py-3.5 text-sm font-black text-[#1a1206]"
              >
                Visit Project
                <ArrowUpRight className="h-4 w-4" />
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ====================== تواصل معايا ====================== */}
      <section id="contact" className="relative mx-auto max-w-6xl px-5 pb-28">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="glass-panel gold-border relative overflow-hidden rounded-[2.5rem]"
        >
          <div className="pointer-events-none absolute -left-16 -top-16 h-64 w-64 rounded-full bg-[#8b5cf6]/12 blur-[100px]" aria-hidden="true" />
          <div className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 rounded-full bg-[#ecc078]/10 blur-[100px]" aria-hidden="true" />
          <div className="relative grid md:grid-cols-5">
            {/* الجانب التعريفي */}
            <div className="flex flex-col justify-between border-b border-white/8 bg-gradient-to-br from-[#101019] to-[#0c0c14] p-8 sm:p-10 md:col-span-2 md:border-b-0 md:border-l">
              <div>
                <span className="mb-3 inline-block text-xs font-black tracking-[0.25em] text-[#ecc078]">تواصل معايا</span>
                <h2 className="mb-4 text-2xl font-black leading-snug sm:text-3xl">
                  عندك فكرة مشروع؟<br />
                  احكيلي عنها
                </h2>
                <p className="text-sm leading-relaxed text-white/50">
                  اكتب اسمك وطلبك، والرسالة هتوصلني واتساب فوراً وهرد عليك في أقرب وقت — عادة خلال ساعة.
                </p>
              </div>
              <div className="mt-10 space-y-3 text-sm font-bold">
                <a
                  href={`tel:${PHONE_DISPLAY}`}
                  className="glass-panel flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-colors hover:text-[#ecc078]"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#ecc078]/12">
                    <Phone className="h-4 w-4 text-[#ecc078]" />
                  </span>
                  <span dir="ltr">{PHONE_DISPLAY}</span>
                </a>
                <a
                  href={`mailto:${EMAIL}`}
                  className="glass-panel flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-colors hover:text-[#ecc078]"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#9f8bf5]/12">
                    <Mail className="h-4 w-4 text-[#9f8bf5]" />
                  </span>
                  <span dir="ltr" className="break-all">{EMAIL}</span>
                </a>
              </div>
            </div>

            {/* الفورم */}
            <div className="p-8 sm:p-10 md:col-span-3">
              <div className="space-y-5">
                <div>
                  <label htmlFor="c-name" className="mb-2 block text-sm font-extrabold">الاسم</label>
                  <input
                    id="c-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="اكتب اسمك"
                    className="w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-sm font-semibold placeholder:text-white/25 focus:border-[#ecc078]/70 focus:bg-white/[0.06] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label htmlFor="c-service" className="mb-2 block text-sm font-extrabold">الخدمة المطلوبة</label>
                  <select
                    id="c-service"
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full cursor-pointer rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-sm font-semibold focus:border-[#ecc078]/70 focus:outline-none transition-colors"
                  >
                    {serviceOptions.map((opt) => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="c-details" className="mb-2 block text-sm font-extrabold">تفاصيل الطلب</label>
                  <textarea
                    id="c-details"
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    rows={5}
                    placeholder="احكيلي عن مشروعك… إيه اللي محتاجه؟ وهل في ميعاد معين للتسليم؟"
                    className="w-full resize-none rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-sm font-semibold placeholder:text-white/25 focus:border-[#ecc078]/70 focus:bg-white/[0.06] focus:outline-none transition-colors"
                  />
                </div>
                <button
                  onClick={sendWhatsApp}
                  disabled={!canSend}
                  className="flex w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-l from-[#2fce6e] to-[#1faa59] py-4 text-sm font-black text-white shadow-[0_18px_40px_-12px_rgba(31,170,89,0.6)] transition-all hover:-translate-y-0.5 hover:shadow-[0_24px_50px_-12px_rgba(31,170,89,0.75)] disabled:cursor-not-allowed disabled:opacity-35 disabled:hover:translate-y-0"
                >
                  <Send className="h-4 w-4" />
                  إرسال عبر واتساب
                </button>
                <p className="flex items-center justify-center gap-1.5 text-center text-[11px] font-bold text-white/30">
                  <CheckCircle2 className="h-3.5 w-3.5 text-[#2fce6e]" />
                  الرسالة بتتفتح مباشرة في واتساب — من غير ما تتخزن في أي مكان تاني.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ====================== الفوتر ====================== */}
      <footer className="border-t border-white/6 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 text-xs font-bold text-white/35 sm:flex-row">
          <span>© {new Date().getFullYear()} يحيى أحمد — جميع الحقوق محفوظة</span>
          <div className="flex items-center gap-5">
            <a href={`tel:${PHONE_DISPLAY}`} dir="ltr" className="transition-colors hover:text-[#ecc078]">{PHONE_DISPLAY}</a>
            <a href={`mailto:${EMAIL}`} dir="ltr" className="transition-colors hover:text-[#ecc078]">{EMAIL}</a>
          </div>
        </div>
      </footer>

      {/* زر واتساب عائم */}
      <a
        href={`https://wa.me/${PHONE_WA}?text=${encodeURIComponent('السلام عليكم يحيى، شوفت موقعك وعايز أكلمك بخصوص مشروع.')}`}
        target="_blank"
        rel="noreferrer"
        aria-label="تواصل واتساب"
        className="fixed bottom-6 left-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-[#2fce6e] to-[#1a8a4a] shadow-[0_18px_40px_-8px_rgba(31,170,89,0.65)] transition-all hover:scale-110 active:scale-95"
      >
        <svg viewBox="0 0 24 24" className="h-7 w-7 fill-white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
      </a>
    </div>
  );
}
